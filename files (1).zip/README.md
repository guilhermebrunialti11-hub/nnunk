# NarifyWeb — site institucional

Site estático (HTML, CSS e JavaScript puro), pronto para publicar.

## Estrutura

```
index.html            → página principal da NarifyWeb
style.css              → estilos do site principal
script.js               → interatividade (menu, FAQ, modal de projetos)
projects/
  barbearia.html        → demonstração "Barbearia Villa"
  restaurante.html       → demonstração "Casa 27"
  imobiliaria.html       → demonstração "Nova Casa Imóveis"
  fotografo.html         → demonstração "Lucas Almeida — Fotógrafo"
```

Cada projeto demonstrativo é uma página completa e independente, aberta em
uma janela simulando um navegador (modal) dentro do site principal.

## Publicar na Vercel

1. Crie um repositório no GitHub com esta pasta.
2. Em vercel.com → **Add New Project** → selecione o repositório.
3. Framework preset: **Other** (site estático). Não é necessário build command.
4. Output directory: raiz do projeto (padrão).
5. Deploy.

Também é possível arrastar a pasta direto em vercel.com/new sem usar Git.

## Imagens

As fotos usadas nas demonstrações vêm de bancos de imagens gratuitos
(Unsplash / Picsum), apenas para fins ilustrativos. Antes de usar este
material com clientes reais, recomenda-se substituir por fotos próprias
de cada negócio.

## Contato configurado

- WhatsApp: +55 45 99114-2749 (wa.me/5545991142749)
- Instagram: @narifyweb (instagram.com/narifyweb)
